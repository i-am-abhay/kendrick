import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { VoiceInputCard } from './components/VoiceInputCard';
import { TextInputCard } from './components/TextInputCard';
import { TranscriptionReviewCard } from './components/TranscriptionReviewCard';
import { CorrectedOutputCard } from './components/CorrectedOutputCard';
import { RulesGuideModal } from './components/RulesGuideModal';
import { AudioRecorder } from './utils/audioRecorder';
import { TTSPlayer } from './utils/ttsPlayer';
import { AppMode, FontSizeLevel, ProcessingStatus, TranslationResult } from './types';
import { ShieldCheck, MessageSquare, AlertCircle } from 'lucide-react';

export default function App() {
  const [mode, setMode] = useState<AppMode>('voice');
  const [status, setStatus] = useState<ProcessingStatus>('idle');
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordingDuration, setRecordingDuration] = useState<number>(0);
  const [audioLevel, setAudioLevel] = useState<number>(0);
  const [rawTranscription, setRawTranscription] = useState<string>('');
  const [directTextInput, setDirectTextInput] = useState<string>('');
  const [translationResult, setTranslationResult] = useState<TranslationResult | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

  // Accessibility States
  const [highContrast, setHighContrast] = useState<boolean>(false);
  const [fontSize, setFontSize] = useState<FontSizeLevel>('large');
  const [useGeminiTTS, setUseGeminiTTS] = useState<boolean>(true);
  const [selectedVoice, setSelectedVoice] = useState<string>('Kore');
  const [isPreparingAudio, setIsPreparingAudio] = useState<boolean>(false);
  const [showRulesModal, setShowRulesModal] = useState<boolean>(false);
  const [lastRecordedAudio, setLastRecordedAudio] = useState<{
    audioBase64: string;
    mimeType: string;
  } | null>(null);

  // Single instances for audio tools
  const recorderRef = useRef<AudioRecorder | null>(null);
  const ttsPlayerRef = useRef<TTSPlayer | null>(null);

  useEffect(() => {
    const recorder = new AudioRecorder();
    recorder.onLevelChange = (lvl) => setAudioLevel(lvl);
    recorder.onDurationChange = (dur) => setRecordingDuration(dur);
    recorderRef.current = recorder;

    const tts = new TTSPlayer();
    tts.onStateChange = (playing) => setIsSpeaking(playing);
    tts.onPreparingChange = (preparing) => setIsPreparingAudio(preparing);
    ttsPlayerRef.current = tts;

    return () => {
      recorder.cancel();
      tts.stop();
    };
  }, []);

  // Map font size to Tailwind classes
  const getFontSizeClass = (level: FontSizeLevel): string => {
    switch (level) {
      case 'normal':
        return 'text-base sm:text-lg leading-relaxed';
      case 'large':
        return 'text-xl sm:text-2xl leading-relaxed';
      case 'extra-large':
        return 'text-2xl sm:text-3xl leading-relaxed';
    }
  };

  const fontSizeClass = getFontSizeClass(fontSize);

  // --- Voice Input Handlers ---
  const sendAudioForTranscription = async (payload: { audioBase64: string; mimeType: string }) => {
    setStatus('transcribing');
    setErrorMessage(null);

    try {
      const response = await fetch('/api/transcribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || 'Failed to transcribe speech.');
      }

      const data = await response.json();
      const transcribedText = (data.transcription || '').trim();

      if (!transcribedText) {
        setErrorMessage('No words could be clearly identified in the audio. You can retry transcription or type directly.');
        setStatus('idle');
        return;
      }

      setRawTranscription(transcribedText);
      setStatus('reviewing_transcription');
    } catch (err: any) {
      console.error('Transcription error:', err);
      setStatus('error');
      setErrorMessage(err.message || 'Speech-to-text processing failed. Please try again or type directly.');
    }
  };

  const handleStartRecording = async () => {
    setErrorMessage(null);
    try {
      if (ttsPlayerRef.current) {
        ttsPlayerRef.current.stop();
      }
      await recorderRef.current?.start();
      setIsRecording(true);
      setStatus('listening');
    } catch (err: any) {
      console.error('Recording start failed:', err);
      setIsRecording(false);
      setStatus('error');
      setErrorMessage(
        err.message || 'Could not access the microphone. Please check your browser permissions or use keyboard input.'
      );
    }
  };

  const handleStopRecording = async () => {
    if (!recorderRef.current) return;
    setIsRecording(false);
    setStatus('transcribing');
    setErrorMessage(null);

    try {
      const payload = await recorderRef.current.stop();
      setLastRecordedAudio(payload);
      await sendAudioForTranscription(payload);
    } catch (err: any) {
      console.error('Recording stop error:', err);
      setStatus('error');
      setErrorMessage(err.message || 'Failed to capture recording audio.');
    }
  };

  const handleRetryTranscription = () => {
    if (lastRecordedAudio) {
      sendAudioForTranscription(lastRecordedAudio);
    }
  };

  const handleCancelRecording = () => {
    recorderRef.current?.cancel();
    setIsRecording(false);
    setStatus('idle');
    setErrorMessage(null);
  };

  // --- Assistive Translation Action ---
  const handleTranslateText = async (textToTranslate: string) => {
    const trimmed = textToTranslate.trim();
    if (!trimmed) return;

    setStatus('translating');
    setErrorMessage(null);

    try {
      const response = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: trimmed }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || 'Assistive translation failed.');
      }

      const result: TranslationResult = await response.json();
      setTranslationResult(result);
      setStatus('completed');
    } catch (err: any) {
      console.error('Translation failed:', err);
      setStatus('error');
      setErrorMessage(err.message || 'Could not complete translation. Please try again.');
    }
  };

  // --- Voice Selection Action ---
  const handleVoiceChange = (voice: string) => {
    handleStopSpeak();
    setSelectedVoice(voice);
    if (translationResult?.correctedText) {
      ttsPlayerRef.current?.preload(translationResult.correctedText, voice);
    }
  };

  // --- TTS Action ---
  const handleSpeakMessage = (text: string) => {
    if (!ttsPlayerRef.current) return;
    ttsPlayerRef.current.speak(text, {
      useGeminiTTS,
      voiceName: selectedVoice,
      rate: 0.95,
    });
  };

  const handleStopSpeak = () => {
    ttsPlayerRef.current?.stop();
    setIsSpeaking(false);
  };

  // --- Reset / Clear Actions ---
  const handleClearAll = () => {
    handleStopSpeak();
    setRawTranscription('');
    setDirectTextInput('');
    setTranslationResult(null);
    setErrorMessage(null);
    setStatus('idle');
  };

  const handleNewMessage = () => {
    handleStopSpeak();
    setRawTranscription('');
    setDirectTextInput('');
    setTranslationResult(null);
    setErrorMessage(null);
    setStatus('idle');
  };

  return (
    <div
      className={`min-h-screen transition-colors duration-200 ${
        highContrast
          ? 'bg-slate-950 text-white'
          : 'bg-slate-50 text-slate-900'
      }`}
    >
      {/* Top Application Header */}
      <Header
        mode={mode}
        onModeChange={(newMode) => {
          setMode(newMode);
          handleStopSpeak();
        }}
        fontSize={fontSize}
        onFontSizeChange={setFontSize}
        highContrast={highContrast}
        onHighContrastToggle={() => setHighContrast(!highContrast)}
        useGeminiTTS={useGeminiTTS}
        onToggleGeminiTTS={() => setUseGeminiTTS(!useGeminiTTS)}
        onShowHelp={() => setShowRulesModal(true)}
      />

      {/* Main Content Stage */}
      <main className="max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6 sm:space-y-8">
        {/* Global Error Notice if any */}
        {errorMessage && status === 'error' && (
          <div
            role="alert"
            className={`p-4 rounded-xl border-2 flex items-start gap-3 ${
              highContrast
                ? 'bg-red-950/60 border-red-500 text-red-100'
                : 'bg-red-50 border-red-400 text-red-900'
            }`}
          >
            <AlertCircle className="w-6 h-6 shrink-0 text-red-500 mt-0.5" />
            <div className="flex-1 text-sm sm:text-base">
              <p className="font-bold">Attention</p>
              <p>{errorMessage}</p>
            </div>
            <button
              type="button"
              onClick={() => setErrorMessage(null)}
              className="font-bold text-xs underline cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Input Phase: Voice Mode OR Keyboard Mode */}
        {mode === 'voice' ? (
          <VoiceInputCard
            status={status}
            isRecording={isRecording}
            recordingDuration={recordingDuration}
            audioLevel={audioLevel}
            error={errorMessage}
            canRetryTranscription={!!lastRecordedAudio}
            onStartRecording={handleStartRecording}
            onStopRecording={handleStopRecording}
            onCancelRecording={handleCancelRecording}
            onRetryTranscription={handleRetryTranscription}
            onSwitchToTextInput={() => setMode('text')}
            highContrast={highContrast}
          />
        ) : (
          <TextInputCard
            inputText={directTextInput}
            onInputChange={setDirectTextInput}
            onClear={() => setDirectTextInput('')}
            onSubmit={() => {
              setRawTranscription(directTextInput);
              handleTranslateText(directTextInput);
            }}
            isLoading={status === 'translating'}
            highContrast={highContrast}
            fontSizeClass={fontSizeClass}
          />
        )}

        {/* Step 1: Visible Transcription for User Review & Editing (Voice Mode) */}
        {rawTranscription && mode === 'voice' && (
          <TranscriptionReviewCard
            transcription={rawTranscription}
            onTranscriptionChange={setRawTranscription}
            onSubmitForTranslation={() => handleTranslateText(rawTranscription)}
            onClear={() => {
              setRawTranscription('');
              setTranslationResult(null);
              setStatus('idle');
            }}
            onReRecord={() => {
              handleStartRecording();
            }}
            status={status}
            highContrast={highContrast}
            fontSizeClass={fontSizeClass}
          />
        )}

        {/* Step 2: Large Easy-to-Read Corrected Communication Area */}
        {translationResult && (
          <CorrectedOutputCard
            result={translationResult}
            onUpdateText={(newText) => {
              setTranslationResult({
                ...translationResult,
                correctedText: newText,
              });
            }}
            onClear={handleClearAll}
            onNewMessage={handleNewMessage}
            onSpeak={handleSpeakMessage}
            onStopSpeak={handleStopSpeak}
            isSpeaking={isSpeaking}
            isPreparingAudio={isPreparingAudio}
            selectedVoice={selectedVoice}
            onVoiceChange={handleVoiceChange}
            useGeminiTTS={useGeminiTTS}
            onToggleGeminiTTS={() => setUseGeminiTTS(!useGeminiTTS)}
            highContrast={highContrast}
            fontSizeClass={fontSizeClass}
          />
        )}

        {/* Assistive Principle Guarantee Card */}
        <div
          className={`p-4 rounded-xl border text-xs sm:text-sm flex flex-col sm:flex-row items-center justify-between gap-3 ${
            highContrast
              ? 'bg-slate-900/60 border-slate-800 text-slate-300'
              : 'bg-white border-slate-200 text-slate-600'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-emerald-500 shrink-0" />
            <span>
              <strong>Zero Guessing Guarantee:</strong> Names, dates, times, and entities are never invented. Genuine ambiguities are flagged for your review.
            </span>
          </div>
          <button
            type="button"
            onClick={() => setShowRulesModal(true)}
            className="font-bold underline text-blue-600 dark:text-amber-400 shrink-0 cursor-pointer"
          >
            Review AI System Rules
          </button>
        </div>
      </main>

      {/* Assistive Rules & Guidelines Modal */}
      <RulesGuideModal
        isOpen={showRulesModal}
        onClose={() => setShowRulesModal(false)}
        highContrast={highContrast}
      />
    </div>
  );
}
