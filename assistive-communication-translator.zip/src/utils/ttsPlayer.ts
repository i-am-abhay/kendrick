export interface TTSOptions {
  rate?: number;
  pitch?: number;
  voiceName?: string;
  useGeminiTTS?: boolean;
}

export class TTSPlayer {
  private utterance: SpeechSynthesisUtterance | null = null;
  private audioContext: AudioContext | null = null;
  private currentSource: AudioBufferSourceNode | null = null;
  // In-memory cache for synthesized audio buffers keyed by "voiceName::text"
  private audioCache: Map<string, AudioBuffer> = new Map();
  public isPlaying: boolean = false;
  public isPreparing: boolean = false;
  public activeVoice: string = 'Kore';
  public onStateChange?: (playing: boolean) => void;
  public onPreparingChange?: (preparing: boolean) => void;

  /**
   * Speak using high-quality natural neural voice or browser speech synthesis fallback.
   * Ensures the exact requested voice is played and previous audio is halted.
   */
  async speak(text: string, options: TTSOptions = {}): Promise<void> {
    this.stop();

    if (!text || !text.trim()) return;

    const voiceName = options.voiceName || 'Kore';
    this.activeVoice = voiceName;
    const preferGemini = options.useGeminiTTS !== false;

    if (preferGemini) {
      try {
        this.isPreparing = true;
        this.onPreparingChange?.(true);
        await this.speakWithBackendTTS(text, voiceName);
        return;
      } catch (err) {
        console.warn(`Backend TTS unavailable for voice ${voiceName}, using dedicated browser voice profile:`, err);
      } finally {
        this.isPreparing = false;
        this.onPreparingChange?.(false);
      }
    }

    // Deterministic fallback using custom voice matching and pitch/rate profiles
    this.speakWithBrowser(text, options);
  }

  /**
   * Pre-generates and caches audio for a given voice and text without immediately playing it.
   */
  async preload(text: string, voiceName: string): Promise<void> {
    if (!text || !text.trim()) return;
    const cacheKey = `${voiceName}::${text.trim()}`;
    if (this.audioCache.has(cacheKey)) return;

    try {
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: text.trim(), voice: voiceName }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.audioBase64) {
          const buffer = await this.decodeBase64Wav(data.audioBase64, data.sampleRate || 24000);
          this.audioCache.set(cacheKey, buffer);
        }
      }
    } catch {
      // Preload errors can fail silently
    }
  }

  private async speakWithBackendTTS(text: string, voiceName: string): Promise<void> {
    const cleanText = text.trim();
    const cacheKey = `${voiceName}::${cleanText}`;

    let audioBuffer: AudioBuffer;

    if (this.audioCache.has(cacheKey)) {
      audioBuffer = this.audioCache.get(cacheKey)!;
    } else {
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: cleanText, voice: voiceName }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `TTS generation failed for voice ${voiceName}`);
      }

      const data = await res.json();
      const { audioBase64, sampleRate = 24000 } = data;
      if (!audioBase64) throw new Error('No audio returned from TTS service');

      audioBuffer = await this.decodeBase64Wav(audioBase64, sampleRate);
      this.audioCache.set(cacheKey, audioBuffer);
    }

    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!this.audioContext || this.audioContext.state === 'closed') {
      this.audioContext = new AudioCtx();
    }
    if (this.audioContext.state === 'suspended') {
      await this.audioContext.resume();
    }

    // Stop any existing sound source before starting new one
    if (this.currentSource) {
      try {
        this.currentSource.stop();
        this.currentSource.disconnect();
      } catch {}
      this.currentSource = null;
    }

    this.currentSource = this.audioContext.createBufferSource();
    this.currentSource.buffer = audioBuffer;
    this.currentSource.connect(this.audioContext.destination);

    this.isPlaying = true;
    this.onStateChange?.(true);

    this.currentSource.onended = () => {
      this.isPlaying = false;
      this.onStateChange?.(false);
      this.currentSource = null;
    };

    this.currentSource.start(0);
  }

  private async decodeBase64Wav(base64: string, sampleRate: number): Promise<AudioBuffer> {
    const binary = atob(base64);
    const len = binary.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binary.charCodeAt(i);
    }

    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!this.audioContext || this.audioContext.state === 'closed') {
      this.audioContext = new AudioCtx();
    }
    if (this.audioContext.state === 'suspended') {
      await this.audioContext.resume();
    }

    // Check for RIFF header
    const isWav =
      len > 12 &&
      bytes[0] === 0x52 &&
      bytes[1] === 0x49 &&
      bytes[2] === 0x46 &&
      bytes[3] === 0x46;

    if (isWav) {
      const arrayBufferCopy = bytes.buffer.slice(0);
      return await this.audioContext.decodeAudioData(arrayBufferCopy);
    }

    // Linear PCM fallback
    const int16Array = new Int16Array(bytes.buffer);
    const float32Array = new Float32Array(int16Array.length);
    for (let i = 0; i < int16Array.length; i++) {
      float32Array[i] = int16Array[i] / 32768.0;
    }
    const buffer = this.audioContext.createBuffer(1, float32Array.length, sampleRate);
    buffer.getChannelData(0).set(float32Array);
    return buffer;
  }

  /**
   * Browser SpeechSynthesis fallback with distinct acoustic profiles for each of the 5 voices
   */
  private speakWithBrowser(text: string, options: TTSOptions = {}): void {
    if (!('speechSynthesis' in window)) {
      console.warn('Speech synthesis is not supported in this browser.');
      return;
    }

    window.speechSynthesis.cancel();

    this.utterance = new SpeechSynthesisUtterance(text);
    const voiceName = options.voiceName || 'Kore';

    // Voice acoustic profiles ensuring each voice sounds audibly and distinctly different
    const voiceProfiles: Record<string, { pitch: number; rate: number; preferGender: 'female' | 'male' | 'neutral' }> = {
      Kore: { pitch: 1.08, rate: 0.94, preferGender: 'female' },
      Puck: { pitch: 1.30, rate: 1.08, preferGender: 'neutral' }, // lively, higher pitch, quicker
      Fenrir: { pitch: 0.70, rate: 0.86, preferGender: 'male' },    // deep, resonant, slow cadence
      Zephyr: { pitch: 1.00, rate: 0.98, preferGender: 'neutral' }, // smooth, clear, articulate
      Charon: { pitch: 0.80, rate: 0.92, preferGender: 'male' },    // authoritative, deep, articulate
    };

    const profile = voiceProfiles[voiceName] || voiceProfiles.Kore;
    this.utterance.pitch = options.pitch || profile.pitch;
    this.utterance.rate = options.rate || profile.rate;

    const voices = window.speechSynthesis.getVoices();
    if (voices.length > 0) {
      const enVoices = voices.filter((v) => v.lang.startsWith('en'));
      const pool = enVoices.length > 0 ? enVoices : voices;

      let matchedVoice: SpeechSynthesisVoice | undefined;

      if (profile.preferGender === 'female') {
        matchedVoice = pool.find(
          (v) =>
            v.name.includes('Female') ||
            v.name.includes('Samantha') ||
            v.name.includes('Victoria') ||
            v.name.includes('Karen') ||
            v.name.includes('Zira') ||
            v.name.includes('Jenny')
        );
      } else if (profile.preferGender === 'male') {
        matchedVoice = pool.find(
          (v) =>
            v.name.includes('Male') ||
            v.name.includes('Daniel') ||
            v.name.includes('Fred') ||
            v.name.includes('Alex') ||
            v.name.includes('David') ||
            v.name.includes('Guy')
        );
      }

      // If no gender-specific match or neutral requested, pick according to voiceName index
      if (!matchedVoice) {
        if (voiceName === 'Puck' && pool.length > 1) {
          matchedVoice = pool[1 % pool.length];
        } else if (voiceName === 'Fenrir' && pool.length > 2) {
          matchedVoice = pool[2 % pool.length];
        } else if (voiceName === 'Zephyr' && pool.length > 3) {
          matchedVoice = pool[3 % pool.length];
        } else if (voiceName === 'Charon' && pool.length > 4) {
          matchedVoice = pool[4 % pool.length];
        } else {
          matchedVoice = pool[0];
        }
      }

      if (matchedVoice) {
        this.utterance.voice = matchedVoice;
      }
    }

    this.utterance.onstart = () => {
      this.isPlaying = true;
      this.onStateChange?.(true);
    };

    this.utterance.onend = () => {
      this.isPlaying = false;
      this.onStateChange?.(false);
      this.utterance = null;
    };

    this.utterance.onerror = (e) => {
      console.warn('Speech synthesis error:', e);
      this.isPlaying = false;
      this.onStateChange?.(false);
      this.utterance = null;
    };

    window.speechSynthesis.speak(this.utterance);
  }

  stop(): void {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    if (this.currentSource) {
      try {
        this.currentSource.stop();
        this.currentSource.disconnect();
      } catch {}
      this.currentSource = null;
    }
    this.isPlaying = false;
    this.isPreparing = false;
    this.onStateChange?.(false);
    this.onPreparingChange?.(false);
    this.utterance = null;
  }
}
