export interface AudioRecorderResult {
  audioBlob: Blob;
  audioBase64: string;
  mimeType: string;
  duration: number; // in seconds
  rmsLevel: number; // 0 to 1
  hasAudibleSound: boolean;
  sampleRate: number; // 16000
}

export class AudioRecorder {
  private mediaStream: MediaStream | null = null;
  private audioContext: AudioContext | null = null;
  private scriptProcessor: ScriptProcessorNode | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private zeroGainNode: GainNode | null = null;
  private pcmFloatChunks: Float32Array[] = [];
  private totalInputSamples: number = 0;
  private animFrameId: number | null = null;
  private durationInterval: any = null;
  private startTime: number = 0;

  public onLevelChange?: (level: number) => void;
  public onDurationChange?: (duration: number) => void;

  async start(): Promise<void> {
    this.pcmFloatChunks = [];
    this.totalInputSamples = 0;

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      throw new Error('Microphone audio capture is not supported in this browser.');
    }

    try {
      // 1. Microphone capture: Optimal settings for disfluent/atypical speech
      // Note: noiseSuppression is disabled so gentle stuttering, vocal fry, or syllable hesitations are preserved
      this.mediaStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: false,
          autoGainControl: true,
          channelCount: 1,
        },
      });

      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) {
        throw new Error('Web Audio API is not supported in this browser environment.');
      }
      this.audioContext = new AudioCtx();
      if (this.audioContext.state === 'suspended') {
        await this.audioContext.resume();
      }

      // 2. Audio stream & buffering via Web Audio API
      this.sourceNode = this.audioContext.createMediaStreamSource(this.mediaStream);

      // Buffer size 4096 gives ~85-93ms latency at 44.1k/48k sample rate
      this.scriptProcessor = this.audioContext.createScriptProcessor(4096, 1, 1);

      this.scriptProcessor.onaudioprocess = (e: AudioProcessingEvent) => {
        const inputData = e.inputBuffer.getChannelData(0);
        // Copy samples into internal buffer
        const copy = new Float32Array(inputData.length);
        copy.set(inputData);
        this.pcmFloatChunks.push(copy);
        this.totalInputSamples += copy.length;

        // Calculate real-time level for UI feedback
        let sumSq = 0;
        for (let i = 0; i < inputData.length; i++) {
          sumSq += inputData[i] * inputData[i];
        }
        const rms = Math.sqrt(sumSq / inputData.length);
        // Normalize 0-100 level (speech is typically 0.01 - 0.25 RMS)
        const normalized = Math.min(100, Math.round(rms * 400));
        this.onLevelChange?.(normalized);
      };

      // Connect to a muted gain node and then destination so scriptProcessor stays active
      this.zeroGainNode = this.audioContext.createGain();
      this.zeroGainNode.gain.value = 0;

      this.sourceNode.connect(this.scriptProcessor);
      this.scriptProcessor.connect(this.zeroGainNode);
      this.zeroGainNode.connect(this.audioContext.destination);

      this.startTime = Date.now();
      this.durationInterval = setInterval(() => {
        const elapsedSec = Math.floor((Date.now() - this.startTime) / 1000);
        this.onDurationChange?.(elapsedSec);
      }, 250);
    } catch (err: any) {
      this.cleanup();
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        throw new Error('Microphone permission was denied. Please allow microphone access to speak.');
      }
      throw err;
    }
  }

  async stop(): Promise<AudioRecorderResult> {
    if (!this.audioContext || this.pcmFloatChunks.length === 0) {
      this.cleanup();
      throw new Error('No audio data captured during recording.');
    }

    const inputSampleRate = this.audioContext.sampleRate;
    const chunks = this.pcmFloatChunks;
    const totalSamples = this.totalInputSamples;

    // Disconnect and release audio stream
    this.cleanup();

    // 3. Audio stream flatten
    const fullAudio = new Float32Array(totalSamples);
    let offset = 0;
    for (const chunk of chunks) {
      fullAudio.set(chunk, offset);
      offset += chunk.length;
    }

    // 4. 16 kHz mono conversion & resampling
    const targetSampleRate = 16000;
    const ratio = inputSampleRate / targetSampleRate;
    const targetLength = Math.round(totalSamples / ratio);
    const resampled = new Float32Array(targetLength);

    for (let i = 0; i < targetLength; i++) {
      const srcIndex = i * ratio;
      const index1 = Math.floor(srcIndex);
      const index2 = Math.min(index1 + 1, totalSamples - 1);
      const fraction = srcIndex - index1;
      resampled[i] = fullAudio[index1] * (1 - fraction) + fullAudio[index2] * fraction;
    }

    // Measure overall signal RMS and peak energy
    let sumSq = 0;
    let peak = 0;
    for (let i = 0; i < targetLength; i++) {
      const absVal = Math.abs(resampled[i]);
      if (absVal > peak) peak = absVal;
      sumSq += resampled[i] * resampled[i];
    }
    const rms = Math.sqrt(sumSq / (targetLength || 1));
    const hasAudibleSound = rms > 0.003 || peak > 0.02;
    const duration = targetLength / targetSampleRate;

    // 5. 16-bit PCM encoding (little-endian)
    const pcmBytes = new Uint8Array(targetLength * 2);
    const pcmView = new DataView(pcmBytes.buffer);
    for (let i = 0; i < targetLength; i++) {
      const s = Math.max(-1, Math.min(1, resampled[i]));
      const intSample = s < 0 ? s * 0x8000 : s * 0x7fff;
      pcmView.setInt16(i * 2, intSample, true);
    }

    // 6. WAV conversion: Construct standard 44-byte RIFF/WAV header
    const wavBytes = new Uint8Array(44 + pcmBytes.length);
    const wavView = new DataView(wavBytes.buffer);

    // RIFF chunk descriptor
    wavView.setUint8(0, 0x52); // R
    wavView.setUint8(1, 0x49); // I
    wavView.setUint8(2, 0x46); // F
    wavView.setUint8(3, 0x46); // F
    wavView.setUint32(4, 36 + pcmBytes.length, true); // Overall file size - 8
    wavView.setUint8(8, 0x57);  // W
    wavView.setUint8(9, 0x41);  // A
    wavView.setUint8(10, 0x56); // V
    wavView.setUint8(11, 0x45); // E

    // fmt subchunk
    wavView.setUint8(12, 0x66); // f
    wavView.setUint8(13, 0x6d); // m
    wavView.setUint8(14, 0x74); // t
    wavView.setUint8(15, 0x20); // ' '
    wavView.setUint32(16, 16, true); // Subchunk1Size = 16 for PCM
    wavView.setUint16(20, 1, true);  // AudioFormat = 1 (Linear PCM)
    wavView.setUint16(22, 1, true);  // NumChannels = 1 (Mono)
    wavView.setUint32(24, targetSampleRate, true); // SampleRate = 16000
    wavView.setUint32(28, targetSampleRate * 1 * 2, true); // ByteRate = 32000
    wavView.setUint16(32, 2, true);  // BlockAlign = 1 channel * 2 bytes
    wavView.setUint16(34, 16, true); // BitsPerSample = 16

    // data subchunk
    wavView.setUint8(36, 0x64); // d
    wavView.setUint8(37, 0x61); // a
    wavView.setUint8(38, 0x74); // t
    wavView.setUint8(39, 0x61); // a
    wavView.setUint32(40, pcmBytes.length, true);
    wavBytes.set(pcmBytes, 44);

    // 7. Package into standard WAV Blob and base64
    const audioBlob = new Blob([wavBytes], { type: 'audio/wav' });
    const audioBase64 = this.uint8ArrayToBase64(wavBytes);

    return {
      audioBlob,
      audioBase64,
      mimeType: 'audio/wav',
      duration,
      rmsLevel: rms,
      hasAudibleSound,
      sampleRate: targetSampleRate,
    };
  }

  cancel(): void {
    this.cleanup();
  }

  private cleanup(): void {
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
    if (this.durationInterval) {
      clearInterval(this.durationInterval);
      this.durationInterval = null;
    }
    if (this.sourceNode) {
      try {
        this.sourceNode.disconnect();
      } catch {}
      this.sourceNode = null;
    }
    if (this.scriptProcessor) {
      try {
        this.scriptProcessor.disconnect();
      } catch {}
      this.scriptProcessor = null;
    }
    if (this.zeroGainNode) {
      try {
        this.zeroGainNode.disconnect();
      } catch {}
      this.zeroGainNode = null;
    }
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((track) => track.stop());
      this.mediaStream = null;
    }
    if (this.audioContext && this.audioContext.state !== 'closed') {
      try {
        this.audioContext.close();
      } catch {}
      this.audioContext = null;
    }
    this.pcmFloatChunks = [];
    this.totalInputSamples = 0;
    this.onLevelChange?.(0);
    this.onDurationChange?.(0);
  }

  private uint8ArrayToBase64(bytes: Uint8Array): string {
    let binary = '';
    const len = bytes.byteLength;
    const chunkSize = 0x8000;
    for (let i = 0; i < len; i += chunkSize) {
      const chunk = bytes.subarray(i, Math.min(i + chunkSize, len));
      binary += String.fromCharCode.apply(null, chunk as any);
    }
    return btoa(binary);
  }
}
