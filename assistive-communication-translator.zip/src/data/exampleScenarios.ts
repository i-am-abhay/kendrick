import { ExampleScenario } from '../types';

export const EXAMPLE_SCENARIOS: ExampleScenario[] = [
  {
    id: 'repetitions',
    label: 'Stuttering & Repetitions',
    category: 'Stuttering & Repetitions',
    rawText: 'C-c-can you... can you please help me find my... my glasses on the... the table?',
    description: 'Resolves sound blocks and word repetitions into a clean, respectful question.',
  },
  {
    id: 'false_start',
    label: 'False Start & Correction',
    category: 'False Start & Self-Correction',
    rawText: 'I want to go to the park no wait the grocery store to buy apples and bread.',
    description: 'Detects mid-stream thought redirection and retains only the final intended goal.',
  },
  {
    id: 'fillers',
    label: 'Fillers & Vocal Hesitations',
    category: 'Fillers & Pauses',
    rawText: 'Um, like, you know, uh, could you please call Dr. Miller, I mean, uh, ask about my test results?',
    description: 'Removes non-semantic crutch words and hesitation sounds without altering meaning.',
  },
  {
    id: 'fragmented',
    label: 'Telegraphic & Dysarthric Syntax',
    category: 'Dysarthric Syntax',
    rawText: 'Pain in knee... need ice pack... no warm compress please on right leg.',
    description: 'Reconstructs fragmented telegraphic phrasing into clear communication while preserving self-correction.',
  },
];
