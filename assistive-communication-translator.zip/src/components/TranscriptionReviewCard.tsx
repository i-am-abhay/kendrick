import React from 'react';
import { ArrowRight, RotateCcw, Trash2, CheckCircle2, Loader2, Sparkles, Edit3 } from 'lucide-react';
import { ProcessingStatus } from '../types';

interface TranscriptionReviewCardProps {
  transcription: string;
  onTranscriptionChange: (text: string) => void;
  onSubmitForTranslation: () => void;
  onClear: () => void;
  onReRecord: () => void;
  status: ProcessingStatus;
  highContrast: boolean;
  fontSizeClass: string;
}

export const TranscriptionReviewCard: React.FC<TranscriptionReviewCardProps> = ({
  transcription,
  onTranscriptionChange,
  onSubmitForTranslation,
  onClear,
  onReRecord,
  status,
  highContrast,
  fontSizeClass,
}) => {
  const isTranslating = status === 'translating';

  return (
    <div
      id="transcription-review-section"
      className={`p-6 sm:p-8 rounded-2xl border transition-all ${
        highContrast
          ? 'bg-slate-900 border-slate-700 text-white'
          : 'bg-white border-slate-200 text-slate-900 shadow-sm'
      }`}
    >
      <div className="max-w-3xl mx-auto space-y-6">
        {/* Header with Step indicator */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full flex items-center justify-center font-bold text-xs bg-blue-600 text-white dark:bg-amber-400 dark:text-slate-950">
                1
              </span>
              <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight">
                Review & Edit Speech Transcription
              </h2>
            </div>
            <p
              className={`text-sm ${
                highContrast ? 'text-slate-300' : 'text-slate-600'
              }`}
            >
              Check the verbatim text below. You can edit or correct any words before processing through the translator.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              id="rerecord-btn"
              onClick={onReRecord}
              disabled={isTranslating}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold border flex items-center gap-1.5 transition-colors ${
                highContrast
                  ? 'border-slate-700 text-slate-300 hover:bg-slate-800'
                  : 'border-slate-300 text-slate-700 hover:bg-slate-100'
              }`}
              title="Record voice again"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Record Again</span>
            </button>
            <button
              type="button"
              id="clear-transcription-btn"
              onClick={onClear}
              disabled={isTranslating}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold border flex items-center gap-1.5 transition-colors ${
                highContrast
                  ? 'border-slate-700 text-slate-300 hover:bg-slate-800'
                  : 'border-slate-300 text-slate-700 hover:bg-slate-100'
              }`}
              title="Clear transcription"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear</span>
            </button>
          </div>
        </div>

        {/* Large Editable Transcription Area */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500">
            <span className="flex items-center gap-1">
              <Edit3 className="w-3.5 h-3.5" /> Editable verbatim text
            </span>
            <span>
              {transcription.trim() ? `${transcription.trim().split(/\s+/).length} words` : '0 words'}
            </span>
          </div>

          <label htmlFor="transcription-textarea" className="sr-only">
            Verbatim speech transcription text for review and editing
          </label>
          <textarea
            id="transcription-textarea"
            rows={5}
            value={transcription}
            onChange={(e) => onTranscriptionChange(e.target.value)}
            disabled={isTranslating}
            placeholder="No speech captured yet. Speak into the microphone or type your message."
            className={`w-full p-4 rounded-xl border-2 transition-all resize-y ${fontSizeClass} ${
              highContrast
                ? 'bg-slate-950 border-slate-700 text-white placeholder-slate-500 focus:border-amber-400'
                : 'bg-slate-50 border-slate-300 text-slate-900 placeholder-slate-400 focus:bg-white focus:border-blue-600'
            }`}
          />
        </div>

        {/* Action Button to Send through Assistive Communication AI */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
          <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
            <span>Removes repetitions, false starts, and hesitation fillers while strictly preserving meaning.</span>
          </div>

          <button
            type="button"
            id="send-to-translator-btn"
            onClick={onSubmitForTranslation}
            disabled={!transcription.trim() || isTranslating}
            className={`w-full sm:w-auto px-8 py-4 rounded-xl font-bold flex items-center justify-center gap-3 text-base sm:text-lg transition-all shadow-md ${
              !transcription.trim() || isTranslating
                ? 'opacity-50 cursor-not-allowed bg-slate-300 text-slate-600 dark:bg-slate-800 dark:text-slate-500'
                : highContrast
                ? 'bg-amber-400 text-slate-950 hover:bg-amber-300 active:scale-98 cursor-pointer'
                : 'bg-blue-700 text-white hover:bg-blue-800 active:scale-98 cursor-pointer'
            }`}
          >
            {isTranslating ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>Translating Communication...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                <span>Translate Communication</span>
                <ArrowRight className="w-5 h-5" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
