import React from 'react';
import { Mic, Type as TypeIcon, Sun, Moon, Volume2, HelpCircle } from 'lucide-react';
import { AppMode, FontSizeLevel } from '../types';

interface HeaderProps {
  mode: AppMode;
  onModeChange: (mode: AppMode) => void;
  fontSize: FontSizeLevel;
  onFontSizeChange: (size: FontSizeLevel) => void;
  highContrast: boolean;
  onHighContrastToggle: () => void;
  useGeminiTTS: boolean;
  onToggleGeminiTTS: () => void;
  onShowHelp: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  mode,
  onModeChange,
  fontSize,
  onFontSizeChange,
  highContrast,
  onHighContrastToggle,
  useGeminiTTS,
  onToggleGeminiTTS,
  onShowHelp,
}) => {
  return (
    <header
      id="app-header"
      className={`border-b transition-colors duration-200 ${
        highContrast
          ? 'bg-slate-950 border-slate-700 text-white'
          : 'bg-white border-slate-200 text-slate-900'
      }`}
    >
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          {/* App Title & Accessibility Purpose */}
          <div className="space-y-1">
            <div className="flex items-center gap-3">
              <div
                className={`p-2.5 rounded-xl flex items-center justify-center ${
                  highContrast ? 'bg-amber-400 text-slate-950' : 'bg-blue-700 text-white'
                }`}
                aria-hidden="true"
              >
                <Volume2 className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-xl sm:text-2xl font-bold tracking-tight">
                  Assistive Communication Translator
                </h1>
                <p
                  className={`text-xs sm:text-sm font-medium ${
                    highContrast ? 'text-slate-300' : 'text-slate-600'
                  }`}
                >
                  Designed for disfluent, dysarthric, and stuttered speech
                </p>
              </div>
            </div>
          </div>

          {/* Accessibility Controls Toolbar */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            {/* Font Sizing Controls */}
            <div
              className={`flex items-center p-1 rounded-xl border ${
                highContrast
                  ? 'bg-slate-900 border-slate-700'
                  : 'bg-slate-100 border-slate-200'
              }`}
              role="group"
              aria-label="Text size adjustment"
            >
              <button
                type="button"
                id="font-size-normal-btn"
                onClick={() => onFontSizeChange('normal')}
                aria-pressed={fontSize === 'normal'}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  fontSize === 'normal'
                    ? highContrast
                      ? 'bg-amber-400 text-slate-950'
                      : 'bg-white text-blue-700 shadow-xs'
                    : highContrast
                    ? 'text-slate-300 hover:text-white'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="Standard Text Size"
              >
                A
              </button>
              <button
                type="button"
                id="font-size-large-btn"
                onClick={() => onFontSizeChange('large')}
                aria-pressed={fontSize === 'large'}
                className={`px-3 py-1.5 rounded-lg text-sm font-bold transition-all ${
                  fontSize === 'large'
                    ? highContrast
                      ? 'bg-amber-400 text-slate-950'
                      : 'bg-white text-blue-700 shadow-xs'
                    : highContrast
                    ? 'text-slate-300 hover:text-white'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="Large Text Size"
              >
                A+
              </button>
              <button
                type="button"
                id="font-size-xl-btn"
                onClick={() => onFontSizeChange('extra-large')}
                aria-pressed={fontSize === 'extra-large'}
                className={`px-3 py-1.5 rounded-lg text-base font-black transition-all ${
                  fontSize === 'extra-large'
                    ? highContrast
                      ? 'bg-amber-400 text-slate-950'
                      : 'bg-white text-blue-700 shadow-xs'
                    : highContrast
                    ? 'text-slate-300 hover:text-white'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="Extra Large Text Size"
              >
                A++
              </button>
            </div>

            {/* High Contrast Mode Toggle */}
            <button
              type="button"
              id="high-contrast-toggle-btn"
              onClick={onHighContrastToggle}
              aria-pressed={highContrast}
              aria-label={highContrast ? 'Switch to Standard Light Theme' : 'Switch to High Contrast Dark Theme'}
              className={`p-2.5 rounded-xl border font-medium flex items-center gap-1.5 text-xs transition-colors ${
                highContrast
                  ? 'bg-slate-900 border-slate-700 text-amber-300 hover:bg-slate-800'
                  : 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200'
              }`}
              title="Toggle High Contrast Display"
            >
              {highContrast ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              <span className="hidden sm:inline font-semibold">
                {highContrast ? 'Light Mode' : 'High Contrast'}
              </span>
            </button>

            {/* Help & Guidelines button */}
            <button
              type="button"
              id="help-guide-btn"
              onClick={onShowHelp}
              aria-label="View how assistive translation works"
              className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                highContrast
                  ? 'bg-slate-900 border-slate-700 text-slate-200 hover:bg-slate-800'
                  : 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <HelpCircle className="w-4 h-4" />
              <span className="hidden sm:inline">Rules & Help</span>
            </button>
          </div>
        </div>

        {/* Input Mode Selector Tabs (Voice vs Text) */}
        <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div
            className={`inline-flex p-1 rounded-xl border ${
              highContrast
                ? 'bg-slate-900 border-slate-700'
                : 'bg-slate-100 border-slate-200'
            }`}
            role="tablist"
            aria-label="Input Method"
          >
            <button
              type="button"
              id="voice-mode-tab-btn"
              role="tab"
              aria-selected={mode === 'voice'}
              onClick={() => onModeChange('voice')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-bold text-sm transition-all ${
                mode === 'voice'
                  ? highContrast
                    ? 'bg-amber-400 text-slate-950 shadow-sm'
                    : 'bg-white text-blue-800 shadow-xs'
                  : highContrast
                  ? 'text-slate-300 hover:text-white'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Mic className="w-4 h-4" />
              <span>Microphone Voice Input</span>
            </button>
            <button
              type="button"
              id="text-mode-tab-btn"
              role="tab"
              aria-selected={mode === 'text'}
              onClick={() => onModeChange('text')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-bold text-sm transition-all ${
                mode === 'text'
                  ? highContrast
                    ? 'bg-amber-400 text-slate-950 shadow-sm'
                    : 'bg-white text-blue-800 shadow-xs'
                  : highContrast
                  ? 'text-slate-300 hover:text-white'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <TypeIcon className="w-4 h-4" />
              <span>Keyboard Text Input</span>
            </button>
          </div>

          {/* Quick Audio Engine indicator */}
          <div className="hidden md:flex items-center gap-2 text-xs font-medium">
            <span className={highContrast ? 'text-slate-400' : 'text-slate-500'}>
              TTS Voice:
            </span>
            <button
              type="button"
              id="toggle-tts-engine-btn"
              onClick={onToggleGeminiTTS}
              className={`px-2.5 py-1 rounded-md border text-xs font-semibold ${
                useGeminiTTS
                  ? highContrast
                    ? 'border-amber-400 text-amber-300 bg-amber-400/10'
                    : 'border-blue-600 text-blue-700 bg-blue-50'
                  : highContrast
                  ? 'border-slate-700 text-slate-300'
                  : 'border-slate-300 text-slate-600'
              }`}
              title="Toggle between browser native voice and Gemini neural voice"
            >
              {useGeminiTTS ? 'Gemini Neural Voice' : 'Device Voice'}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
