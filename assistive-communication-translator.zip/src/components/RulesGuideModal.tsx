import React from 'react';
import { X, ShieldCheck, CheckCircle, AlertOctagon } from 'lucide-react';

interface RulesGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  highContrast: boolean;
}

export const RulesGuideModal: React.FC<RulesGuideModalProps> = ({
  isOpen,
  onClose,
  highContrast,
}) => {
  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="rules-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs"
    >
      <div
        className={`w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl border-2 p-6 sm:p-8 shadow-2xl transition-all ${
          highContrast
            ? 'bg-slate-900 border-amber-400 text-white'
            : 'bg-white border-slate-300 text-slate-900'
        }`}
      >
        <div className="flex items-center justify-between border-b pb-4 mb-4 border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-6 h-6 text-blue-600 dark:text-amber-400" />
            <h2 id="rules-modal-title" className="text-xl font-extrabold">
              Assistive Communication AI Rules & Safeguards
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close guide"
            className="p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 text-sm leading-relaxed">
          <div className="p-3.5 rounded-xl bg-blue-50 dark:bg-slate-800 border border-blue-200 dark:border-slate-700">
            <p className="font-bold text-blue-900 dark:text-amber-300 mb-1">
              Purpose & Intent:
            </p>
            <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300">
              This system is an AAC (Augmentative and Alternative Communication) translation tool, not a conversational chatbot. It translates what you say into clear, fluent communication without ever answering or altering your thoughts.
            </p>
          </div>

          <div className="space-y-3">
            <div className="flex items-start gap-2.5">
              <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
              <div>
                <strong className="block text-slate-900 dark:text-white">
                  Stuttering & Sound Repetitions
                </strong>
                <span className="text-xs sm:text-sm text-slate-600 dark:text-slate-300">
                  Filters involuntary word, syllable, and phrase repetitions (e.g. "I I I want to to go" → "I want to go").
                </span>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
              <div>
                <strong className="block text-slate-900 dark:text-white">
                  False Starts & Mid-Stream Corrections
                </strong>
                <span className="text-xs sm:text-sm text-slate-600 dark:text-slate-300">
                  Detects when a speaker changes course mid-sentence and accurately preserves ONLY the final intended statement (e.g. "water no tea hot tea" → "hot tea").
                </span>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
              <div>
                <strong className="block text-slate-900 dark:text-white">
                  Filler Words & Hesitation Sounds
                </strong>
                <span className="text-xs sm:text-sm text-slate-600 dark:text-slate-300">
                  Cleans vocal crutches ("um", "uh", "like", "you know", "er") without losing emotional cadence or tone.
                </span>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <AlertOctagon className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
              <div>
                <strong className="block text-slate-900 dark:text-white">
                  Zero Hallucination / No Invented Information
                </strong>
                <span className="text-xs sm:text-sm text-slate-600 dark:text-slate-300">
                  The AI is strictly prohibited from inventing names, dates, times, medication names, or numbers. If speech is ambiguous, it alerts you rather than guessing.
                </span>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
              <div>
                <strong className="block text-slate-900 dark:text-white">
                  Strict Non-Conversational Behavior
                </strong>
                <span className="text-xs sm:text-sm text-slate-600 dark:text-slate-300">
                  If you ask "What time does the clinic open?", it outputs that exact question cleanly, rather than trying to look up the answer.
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-slate-200 dark:border-slate-800 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className={`px-6 py-2.5 rounded-xl font-bold text-sm ${
              highContrast
                ? 'bg-amber-400 text-slate-950 hover:bg-amber-300'
                : 'bg-blue-700 text-white hover:bg-blue-800'
            }`}
          >
            Understood
          </button>
        </div>
      </div>
    </div>
  );
};
