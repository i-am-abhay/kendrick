import React from 'react';
import { Sparkles, Trash2, ArrowRight } from 'lucide-react';
import { EXAMPLE_SCENARIOS } from '../data/exampleScenarios';
import { ExampleScenario } from '../types';

interface TextInputCardProps {
  inputText: string;
  onInputChange: (text: string) => void;
  onClear: () => void;
  onSubmit: () => void;
  isLoading: boolean;
  highContrast: boolean;
  fontSizeClass: string;
}

export const TextInputCard: React.FC<TextInputCardProps> = ({
  inputText,
  onInputChange,
  onClear,
  onSubmit,
  isLoading,
  highContrast,
  fontSizeClass,
}) => {
  const handleSelectExample = (example: ExampleScenario) => {
    onInputChange(example.rawText);
  };

  return (
    <div
      id="text-input-section"
      className={`p-6 sm:p-8 rounded-2xl border transition-all ${
        highContrast
          ? 'bg-slate-900 border-slate-700 text-white'
          : 'bg-white border-slate-200 text-slate-900 shadow-sm'
      }`}
    >
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight">
              Type or Paste Communication
            </h2>
            <p
              className={`text-sm ${
                highContrast ? 'text-slate-300' : 'text-slate-600'
              }`}
            >
              Enter rough, repetitive, or fragmented text. The Assistive Translator will reconstruct the intended message.
            </p>
          </div>
          {inputText && (
            <button
              type="button"
              id="clear-input-btn"
              onClick={onClear}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors ${
                highContrast
                  ? 'border-slate-700 text-slate-300 hover:bg-slate-800'
                  : 'border-slate-300 text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Trash2 className="w-3.5 h-3.5" />
              Clear Input
            </button>
          )}
        </div>

        {/* Text Area */}
        <div className="relative">
          <label htmlFor="user-text-input" className="sr-only">
            Type your message with any repetitions, fillers, or corrections
          </label>
          <textarea
            id="user-text-input"
            rows={4}
            value={inputText}
            onChange={(e) => onInputChange(e.target.value)}
            placeholder="Type your message here... (e.g., 'I want the tea no coffee hot coffee please')"
            className={`w-full p-4 rounded-xl border-2 transition-all resize-y ${fontSizeClass} ${
              highContrast
                ? 'bg-slate-950 border-slate-700 text-white placeholder-slate-500 focus:border-amber-400'
                : 'bg-slate-50 border-slate-300 text-slate-900 placeholder-slate-400 focus:bg-white focus:border-blue-600'
            }`}
          />
          <div className="flex justify-between items-center mt-2 text-xs font-medium text-slate-500">
            <span>{inputText.trim() ? `${inputText.trim().split(/\s+/).length} words` : '0 words'}</span>
            <span>Accurate meaning preservation guaranteed</span>
          </div>
        </div>

        {/* Action Button */}
        <div className="flex justify-end">
          <button
            type="button"
            id="submit-text-btn"
            disabled={!inputText.trim() || isLoading}
            onClick={onSubmit}
            className={`w-full sm:w-auto px-8 py-3.5 rounded-xl font-bold flex items-center justify-center gap-2.5 transition-all text-base shadow-sm ${
              !inputText.trim() || isLoading
                ? 'opacity-50 cursor-not-allowed bg-slate-300 text-slate-600 dark:bg-slate-800 dark:text-slate-500'
                : highContrast
                ? 'bg-amber-400 text-slate-950 hover:bg-amber-300 active:scale-98 cursor-pointer'
                : 'bg-blue-700 text-white hover:bg-blue-800 active:scale-98 cursor-pointer'
            }`}
          >
            <span>Process with Assistive AI</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Sample Scenarios for Testing */}
        <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-500">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Try an Assistive Disfluency Example:</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {EXAMPLE_SCENARIOS.map((scenario) => (
              <button
                key={scenario.id}
                type="button"
                id={`example-btn-${scenario.id}`}
                onClick={() => handleSelectExample(scenario)}
                className={`p-3 rounded-xl border text-left transition-all text-xs flex flex-col gap-1 ${
                  highContrast
                    ? 'bg-slate-950/60 border-slate-800 hover:border-amber-400/60 text-slate-200'
                    : 'bg-slate-50 border-slate-200 hover:border-blue-300 hover:bg-blue-50/50 text-slate-800'
                }`}
              >
                <div className="font-bold flex items-center justify-between">
                  <span>{scenario.label}</span>
                  <span className="text-[10px] opacity-70 px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-800">
                    Sample
                  </span>
                </div>
                <p className="line-clamp-2 italic text-slate-600 dark:text-slate-400">
                  "{scenario.rawText}"
                </p>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
