import React, { useState } from 'react';
import { Volume2, VolumeX, Copy, Check, Edit3, Trash2, AlertTriangle, CheckCircle2, RotateCcw, Sparkles, Loader2 } from 'lucide-react';
import { TranslationResult } from '../types';

interface CorrectedOutputCardProps {
  result: TranslationResult;
  onUpdateText: (newText: string) => void;
  onClear: () => void;
  onNewMessage: () => void;
  onSpeak: (text: string) => void;
  onStopSpeak: () => void;
  isSpeaking: boolean;
  isPreparingAudio?: boolean;
  selectedVoice?: string;
  onVoiceChange?: (voice: string) => void;
  useGeminiTTS?: boolean;
  onToggleGeminiTTS?: () => void;
  highContrast: boolean;
  fontSizeClass: string;
}

export const CorrectedOutputCard: React.FC<CorrectedOutputCardProps> = ({
  result,
  onUpdateText,
  onClear,
  onNewMessage,
  onSpeak,
  onStopSpeak,
  isSpeaking,
  isPreparingAudio = false,
  selectedVoice = 'Kore',
  onVoiceChange,
  useGeminiTTS = true,
  onToggleGeminiTTS,
  highContrast,
  fontSizeClass,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(result.correctedText);
  const [copied, setCopied] = useState(false);
  const [speechRate, setSpeechRate] = useState<number>(0.95);

  // Sync editText if result changes
  React.useEffect(() => {
    setEditText(result.correctedText);
  }, [result.correctedText]);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(result.correctedText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (e) {
      console.error('Failed to copy text', e);
    }
  };

  const handleSaveEdit = () => {
    onUpdateText(editText);
    setIsEditing(false);
  };

  const handleCancelEdit = () => {
    setEditText(result.correctedText);
    setIsEditing(false);
  };

  const handleToggleSpeak = () => {
    if (isSpeaking) {
      onStopSpeak();
    } else {
      onSpeak(result.correctedText);
    }
  };

  return (
    <div
      id="corrected-communication-section"
      className={`p-6 sm:p-8 rounded-2xl border-2 transition-all ${
        highContrast
          ? 'bg-slate-900 border-amber-400 text-white shadow-xl'
          : 'bg-white border-blue-600 text-slate-900 shadow-md'
      }`}
    >
      <div className="max-w-3xl mx-auto space-y-6">
        {/* Step Header & Title */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full flex items-center justify-center font-bold text-xs bg-emerald-600 text-white">
                2
              </span>
              <h2 className="text-xl sm:text-2xl font-black tracking-tight">
                Corrected Communication
              </h2>
            </div>
            <p
              className={`text-sm ${
                highContrast ? 'text-slate-300' : 'text-slate-600'
              }`}
            >
              Reconstructed message preserving 100% of your meaning and voice.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              id="new-message-action-btn"
              onClick={onNewMessage}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold border flex items-center gap-1.5 transition-colors ${
                highContrast
                  ? 'border-slate-700 text-slate-300 hover:bg-slate-800'
                  : 'border-slate-300 text-slate-700 hover:bg-slate-100'
              }`}
              title="Start a new message"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>New Message</span>
            </button>
            <button
              type="button"
              id="clear-output-action-btn"
              onClick={onClear}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold border flex items-center gap-1.5 transition-colors ${
                highContrast
                  ? 'border-slate-700 text-slate-300 hover:bg-slate-800'
                  : 'border-slate-300 text-slate-700 hover:bg-slate-100'
              }`}
              title="Clear output"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear</span>
            </button>
          </div>
        </div>

        {/* Ambiguity Alert Warning (if any ambiguous words detected) */}
        {result.ambiguities && result.ambiguities.length > 0 && (
          <div
            id="ambiguity-warning-box"
            role="alert"
            className={`p-4 rounded-xl border-2 flex items-start gap-3 ${
              highContrast
                ? 'bg-amber-950/40 border-amber-400 text-amber-200'
                : 'bg-amber-50 border-amber-400 text-amber-900'
            }`}
          >
            <AlertTriangle className="w-6 h-6 shrink-0 text-amber-500 mt-0.5" />
            <div className="space-y-1 text-sm">
              <p className="font-extrabold text-base">Please Verify Ambiguous Phrasing</p>
              <p className="text-xs sm:text-sm">
                The translator identified phrasing that could be interpreted in more than one way without guessing:
              </p>
              <ul className="list-disc list-inside text-xs sm:text-sm font-semibold pt-1">
                {result.ambiguities.map((item, idx) => (
                  <li key={idx}>{item}</li>
                ))}
              </ul>
              <p className="text-xs pt-1 opacity-90">
                You can press the <strong>Edit</strong> button below to adjust the wording to your exact intent.
              </p>
            </div>
          </div>
        )}

        {/* Large Easy-to-Read Area Showing the Corrected Communication */}
        <div
          className={`p-6 sm:p-8 rounded-2xl border-2 transition-all ${
            highContrast
              ? 'bg-slate-950 border-slate-700 text-white'
              : 'bg-blue-50/40 border-blue-200 text-slate-950'
          }`}
        >
          {isEditing ? (
            <div className="space-y-3">
              <label htmlFor="edit-corrected-textarea" className="block text-xs font-bold uppercase tracking-wider text-slate-500">
                Edit Final Communication
              </label>
              <textarea
                id="edit-corrected-textarea"
                rows={4}
                value={editText}
                onChange={(e) => setEditText(e.target.value)}
                className={`w-full p-4 rounded-xl border-2 ${fontSizeClass} ${
                  highContrast
                    ? 'bg-slate-900 border-amber-400 text-white focus:outline-none'
                    : 'bg-white border-blue-600 text-slate-900 focus:outline-none'
                }`}
              />
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  id="cancel-edit-btn"
                  onClick={handleCancelEdit}
                  className={`px-4 py-2 rounded-xl text-xs font-bold border transition-colors ${
                    highContrast
                      ? 'border-slate-700 text-slate-300 hover:bg-slate-800'
                      : 'border-slate-300 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  Cancel
                </button>
                <button
                  type="button"
                  id="save-edit-btn"
                  onClick={handleSaveEdit}
                  className={`px-5 py-2 rounded-xl text-xs font-bold transition-colors ${
                    highContrast
                      ? 'bg-amber-400 text-slate-950 hover:bg-amber-300'
                      : 'bg-blue-700 text-white hover:bg-blue-800'
                  }`}
                >
                  Save Changes
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div
                id="corrected-message-text"
                className={`font-semibold leading-relaxed break-words select-all ${fontSizeClass} ${
                  isSpeaking ? 'speaking-pulse text-blue-700 dark:text-amber-300' : ''
                }`}
              >
                "{result.correctedText}"
              </div>

              {/* Adjustments Summary Badges */}
              {result.changesSummary && result.changesSummary.length > 0 && (
                <div className="pt-3 border-t border-slate-200 dark:border-slate-800">
                  <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" /> Adjustments Applied:
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {result.changesSummary.map((change, idx) => (
                      <span
                        key={idx}
                        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium ${
                          highContrast
                            ? 'bg-slate-800 text-amber-300 border border-slate-700'
                            : 'bg-blue-100 text-blue-800 border border-blue-200'
                        }`}
                      >
                        <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                        {change}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Voice Selection & Engine Bar */}
        <div
          className={`p-4 rounded-xl border flex flex-col gap-3 text-xs ${
            highContrast
              ? 'bg-slate-950 border-slate-700 text-slate-300'
              : 'bg-slate-50 border-slate-200 text-slate-700'
          }`}
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="font-bold uppercase tracking-wider text-[11px] text-slate-500 dark:text-slate-400">
                Speech Voice:
              </span>
              <span className="font-semibold text-slate-900 dark:text-slate-100">
                {selectedVoice === 'Kore' && 'Kore — Warm Natural Intonation'}
                {selectedVoice === 'Puck' && 'Puck — Expressive & Lively'}
                {selectedVoice === 'Fenrir' && 'Fenrir — Deep & Resonant'}
                {selectedVoice === 'Zephyr' && 'Zephyr — Clear, Smooth & Measured'}
                {selectedVoice === 'Charon' && 'Charon — Articulate & Authoritative'}
              </span>
            </div>

            {onToggleGeminiTTS && (
              <button
                type="button"
                id="output-toggle-tts-engine-btn"
                onClick={onToggleGeminiTTS}
                className={`px-2.5 py-1 rounded-md border font-semibold shrink-0 cursor-pointer transition-colors ${
                  useGeminiTTS
                    ? highContrast
                      ? 'border-amber-400 text-amber-300 bg-amber-400/10'
                      : 'border-blue-600 text-blue-700 bg-blue-50'
                    : highContrast
                    ? 'border-slate-700 text-slate-300'
                    : 'border-slate-300 text-slate-600'
                }`}
              >
                {useGeminiTTS ? 'Using High-Fidelity Voice Engine' : 'Using Device Speech Engine'}
              </button>
            )}
          </div>

          <div className="flex items-center gap-1.5 flex-wrap">
            {[
              { id: 'Kore', label: 'Kore (Warm Natural)' },
              { id: 'Puck', label: 'Puck (Expressive)' },
              { id: 'Fenrir', label: 'Fenrir (Deep Resonance)' },
              { id: 'Zephyr', label: 'Zephyr (Clear & Smooth)' },
              { id: 'Charon', label: 'Charon (Articulate)' },
            ].map((v) => (
              <button
                key={v.id}
                type="button"
                id={`voice-btn-${v.id.toLowerCase()}`}
                onClick={() => {
                  onStopSpeak?.();
                  onVoiceChange?.(v.id);
                }}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                  selectedVoice === v.id
                    ? highContrast
                      ? 'bg-amber-400 text-slate-950 font-extrabold shadow-sm'
                      : 'bg-blue-700 text-white font-extrabold shadow-sm'
                    : highContrast
                    ? 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-700'
                    : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-200'
                }`}
              >
                {v.label}
              </button>
            ))}
          </div>
        </div>

        {/* Action Buttons: Speak, Copy, Edit, Clear */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          {/* Text-to-Speech Main Button */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              id="speak-corrected-btn"
              onClick={handleToggleSpeak}
              disabled={isPreparingAudio}
              aria-label={
                isSpeaking
                  ? 'Stop speaking audio'
                  : isPreparingAudio
                  ? 'Generating natural audio buffer'
                  : 'Speak corrected message aloud'
              }
              className={`px-6 py-3.5 rounded-xl font-extrabold flex items-center gap-2.5 text-base sm:text-lg transition-all shadow-md cursor-pointer ${
                isPreparingAudio
                  ? 'bg-slate-400 text-white cursor-wait'
                  : isSpeaking
                  ? 'bg-red-600 hover:bg-red-700 text-white ring-4 ring-red-300 dark:ring-red-900'
                  : highContrast
                  ? 'bg-amber-400 hover:bg-amber-300 text-slate-950 ring-2 ring-amber-300'
                  : 'bg-blue-700 hover:bg-blue-800 text-white ring-2 ring-blue-300'
              }`}
            >
              {isPreparingAudio ? (
                <>
                  <Loader2 className="w-6 h-6 animate-spin" />
                  <span>Preparing Natural Speech...</span>
                </>
              ) : isSpeaking ? (
                <>
                  <VolumeX className="w-6 h-6 animate-pulse" />
                  <span>Stop Speaking</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-6 h-6" />
                  <span>Speak Aloud</span>
                </>
              )}
            </button>
          </div>

          {/* Utility Buttons: Copy, Edit, Clear */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              id="copy-corrected-btn"
              onClick={handleCopy}
              className={`px-4 py-3 rounded-xl font-bold flex items-center gap-2 text-sm border-2 transition-all ${
                copied
                  ? 'bg-emerald-600 text-white border-emerald-600'
                  : highContrast
                  ? 'border-slate-700 bg-slate-800 hover:bg-slate-700 text-white'
                  : 'border-slate-300 bg-white hover:bg-slate-50 text-slate-800'
              }`}
              title="Copy message to clipboard"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-white" />
                  <span>Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copy</span>
                </>
              )}
            </button>

            <button
              type="button"
              id="edit-output-toggle-btn"
              onClick={() => setIsEditing(!isEditing)}
              className={`px-4 py-3 rounded-xl font-bold flex items-center gap-2 text-sm border-2 transition-all ${
                isEditing
                  ? highContrast
                    ? 'border-amber-400 bg-amber-400/20 text-amber-300'
                    : 'border-blue-600 bg-blue-50 text-blue-800'
                  : highContrast
                  ? 'border-slate-700 bg-slate-800 hover:bg-slate-700 text-white'
                  : 'border-slate-300 bg-white hover:bg-slate-50 text-slate-800'
              }`}
              title="Edit corrected message"
            >
              <Edit3 className="w-4 h-4" />
              <span>{isEditing ? 'Close Edit' : 'Edit'}</span>
            </button>

            <button
              type="button"
              id="clear-all-btn"
              onClick={onClear}
              className={`px-4 py-3 rounded-xl font-bold flex items-center gap-2 text-sm border-2 transition-all ${
                highContrast
                  ? 'border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300'
                  : 'border-slate-300 bg-white hover:bg-slate-50 text-slate-600'
              }`}
              title="Clear all"
            >
              <Trash2 className="w-4 h-4" />
              <span>Clear</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
