import React from 'react';
import { Mic, Square, Loader2, AlertCircle, Sparkles, Volume2 } from 'lucide-react';
import { ProcessingStatus } from '../types';

interface VoiceInputCardProps {
  status: ProcessingStatus;
  isRecording: boolean;
  recordingDuration: number;
  audioLevel: number;
  error: string | null;
  canRetryTranscription?: boolean;
  onStartRecording: () => void;
  onStopRecording: () => void;
  onCancelRecording: () => void;
  onRetryTranscription?: () => void;
  onSwitchToTextInput?: () => void;
  highContrast: boolean;
}

export const VoiceInputCard: React.FC<VoiceInputCardProps> = ({
  status,
  isRecording,
  recordingDuration,
  audioLevel,
  error,
  canRetryTranscription,
  onStartRecording,
  onStopRecording,
  onCancelRecording,
  onRetryTranscription,
  onSwitchToTextInput,
  highContrast,
}) => {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const isTranscribing = status === 'transcribing';

  return (
    <div
      id="voice-input-section"
      className={`p-6 sm:p-8 rounded-2xl border transition-all ${
        highContrast
          ? 'bg-slate-900 border-slate-700 text-white'
          : 'bg-white border-slate-200 text-slate-900 shadow-sm'
      }`}
    >
      <div className="flex flex-col items-center text-center max-w-xl mx-auto space-y-6">
        {/* Title & Guidance */}
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-blue-100 text-blue-800 dark:bg-amber-400/20 dark:text-amber-300">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Disfluent & Imperfect Speech Input</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            {isRecording
              ? 'Listening at your pace...'
              : isTranscribing
              ? 'Transcribing your speech...'
              : 'Voice Input'}
          </h2>
          <p
            className={`text-base sm:text-lg ${
              highContrast ? 'text-slate-300' : 'text-slate-600'
            }`}
          >
            {isRecording
              ? 'Speak naturally. Repetitions, stuttering, and long pauses are completely supported.'
              : isTranscribing
              ? 'Capturing verbatim words, self-corrections, and hesitations without guessing.'
              : 'Tap the large microphone button when ready. Pauses will not cut you off.'}
          </p>
        </div>

        {/* Big Tactile Microphone Button */}
        <div className="relative py-2 flex items-center justify-center">
          {/* Pulsing ring during recording */}
          {isRecording && (
            <div
              className={`absolute inset-0 rounded-full mic-active-pulse ${
                highContrast ? 'bg-amber-400/20' : 'bg-red-500/20'
              }`}
              style={{ transform: 'scale(1.25)' }}
            />
          )}

          {!isRecording && !isTranscribing && (
            <button
              type="button"
              id="start-mic-btn"
              onClick={onStartRecording}
              aria-label="Start recording speech"
              className={`w-28 h-28 sm:w-32 sm:h-32 rounded-full flex flex-col items-center justify-center gap-1 font-bold transition-transform active:scale-95 cursor-pointer shadow-lg hover:shadow-xl focus:outline-none ${
                highContrast
                  ? 'bg-amber-400 text-slate-950 hover:bg-amber-300 hover:ring-4 hover:ring-amber-400/40'
                  : 'bg-blue-700 text-white hover:bg-blue-800 hover:ring-4 hover:ring-blue-300'
              }`}
            >
              <Mic className="w-12 h-12" />
              <span className="text-xs uppercase tracking-wider font-extrabold">Tap to Talk</span>
            </button>
          )}

          {isRecording && (
            <button
              type="button"
              id="stop-mic-btn"
              onClick={onStopRecording}
              aria-label="Finish speaking and generate transcription"
              className={`w-28 h-28 sm:w-32 sm:h-32 rounded-full flex flex-col items-center justify-center gap-1 font-bold transition-transform active:scale-95 cursor-pointer shadow-lg ring-4 ${
                highContrast
                  ? 'bg-red-600 text-white ring-red-400 hover:bg-red-500'
                  : 'bg-red-600 text-white ring-red-300 hover:bg-red-700'
              }`}
            >
              <Square className="w-10 h-10 fill-current" />
              <span className="text-xs uppercase tracking-wider font-extrabold">Done Speaking</span>
            </button>
          )}

          {isTranscribing && (
            <div
              className={`w-28 h-28 sm:w-32 sm:h-32 rounded-full flex flex-col items-center justify-center gap-2 shadow-lg ${
                highContrast ? 'bg-slate-800 text-amber-300' : 'bg-slate-100 text-blue-700'
              }`}
              role="status"
              aria-live="polite"
            >
              <Loader2 className="w-10 h-10 animate-spin" />
              <span className="text-xs font-bold uppercase tracking-wider">Processing</span>
            </div>
          )}
        </div>

        {/* Active Recording Metrics & Level Meter */}
        {isRecording && (
          <div className="w-full max-w-sm space-y-3">
            <div className="flex items-center justify-between text-sm font-mono font-bold">
              <span className="flex items-center gap-2 text-red-500 dark:text-red-400">
                <span className="w-3 h-3 rounded-full bg-red-600 animate-pulse" />
                RECORDING
              </span>
              <span className={highContrast ? 'text-amber-300' : 'text-slate-700'}>
                {formatTime(recordingDuration)}
              </span>
            </div>

            {/* Audio volume visualizer meter */}
            <div className="space-y-1">
              <div
                className={`h-3 rounded-full overflow-hidden border ${
                  highContrast ? 'bg-slate-800 border-slate-700' : 'bg-slate-100 border-slate-300'
                }`}
              >
                <div
                  className={`h-full transition-all duration-75 rounded-full ${
                    audioLevel > 50
                      ? 'bg-emerald-500'
                      : highContrast
                      ? 'bg-amber-400'
                      : 'bg-blue-600'
                  }`}
                  style={{ width: `${Math.max(6, audioLevel)}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-xs font-medium text-slate-500">
                <span className="flex items-center gap-1">
                  <Volume2 className="w-3 h-3" /> Voice activity level
                </span>
                <span>{audioLevel > 15 ? 'Picking up voice' : 'Waiting for sound'}</span>
              </div>
            </div>

            {/* Action buttons while recording */}
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                type="button"
                id="cancel-recording-btn"
                onClick={onCancelRecording}
                className={`px-4 py-2 rounded-xl text-sm font-semibold border transition-colors ${
                  highContrast
                    ? 'border-slate-700 text-slate-300 hover:bg-slate-800'
                    : 'border-slate-300 text-slate-700 hover:bg-slate-100'
                }`}
              >
                Cancel
              </button>
              <button
                type="button"
                id="finish-recording-action-btn"
                onClick={onStopRecording}
                className={`px-5 py-2 rounded-xl text-sm font-bold shadow-xs transition-colors ${
                  highContrast
                    ? 'bg-amber-400 text-slate-950 hover:bg-amber-300'
                    : 'bg-blue-700 text-white hover:bg-blue-800'
                }`}
              >
                Finish & Transcribe
              </button>
            </div>
          </div>
        )}

        {/* Error message banner */}
        {error && (
          <div
            id="voice-error-banner"
            role="alert"
            className={`w-full p-4 sm:p-5 rounded-xl border flex flex-col gap-3 text-left ${
              highContrast
                ? 'bg-red-950/60 border-red-700 text-red-100'
                : 'bg-red-50 border-red-300 text-red-900'
            }`}
          >
            <div className="flex items-start gap-3">
              <AlertCircle className="w-6 h-6 shrink-0 text-red-500 mt-0.5" />
              <div className="space-y-1 text-sm flex-1">
                <p className="font-bold">Voice Input Notice</p>
                <p>{error}</p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-red-200 dark:border-red-900/60">
              {canRetryTranscription && onRetryTranscription && (
                <button
                  type="button"
                  id="retry-transcription-btn"
                  onClick={onRetryTranscription}
                  className={`px-4 py-2 rounded-lg text-xs font-bold transition-all shadow-xs cursor-pointer ${
                    highContrast
                      ? 'bg-amber-400 text-slate-950 hover:bg-amber-300'
                      : 'bg-blue-700 text-white hover:bg-blue-800'
                  }`}
                >
                  Retry Transcription
                </button>
              )}
              {onSwitchToTextInput && (
                <button
                  type="button"
                  id="switch-to-text-btn"
                  onClick={onSwitchToTextInput}
                  className={`px-3 py-2 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                    highContrast
                      ? 'border-slate-700 text-slate-200 hover:bg-slate-800'
                      : 'border-slate-300 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  Switch to Keyboard Text Input
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
