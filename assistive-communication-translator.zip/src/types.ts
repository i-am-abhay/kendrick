export type AppMode = 'voice' | 'text';

export type ProcessingStatus = 
  | 'idle'
  | 'listening'
  | 'transcribing'
  | 'reviewing_transcription'
  | 'translating'
  | 'completed'
  | 'error';

export interface TranslationResult {
  correctedText: string;
  changesSummary: string[];
  ambiguities: string[];
}

export type FontSizeLevel = 'normal' | 'large' | 'extra-large';

export interface AccessibilitySettings {
  highContrast: boolean;
  fontSize: FontSizeLevel;
  speechRate: number; // 0.7 to 1.3
  preferredTTSVoice: string; // 'browser' or Gemini voice name
}

export interface ExampleScenario {
  id: string;
  label: string;
  category: 'Stuttering & Repetitions' | 'False Start & Self-Correction' | 'Fillers & Pauses' | 'Dysarthric Syntax';
  rawText: string;
  description: string;
}
