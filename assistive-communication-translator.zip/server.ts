import express from "express";
import path from "path";
import fs from "fs";
import { execFile } from "child_process";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type, Modality } from "@google/genai";
import "dotenv/config";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

// Helper: Convert raw 16-bit linear PCM to a standard RIFF/WAVE buffer
function pcmToWav(
  pcmBuffer: Buffer,
  sampleRate: number = 24000,
  numChannels: number = 1,
  bitDepth: number = 16
): Buffer {
  const byteRate = (sampleRate * numChannels * bitDepth) / 8;
  const blockAlign = (numChannels * bitDepth) / 8;
  const dataSize = pcmBuffer.length;
  const headerSize = 44;
  const buffer = Buffer.alloc(headerSize + dataSize);

  // RIFF chunk descriptor
  buffer.write("RIFF", 0);
  buffer.writeUInt32LE(36 + dataSize, 4);
  buffer.write("WAVE", 8);

  // fmt sub-chunk
  buffer.write("fmt ", 12);
  buffer.writeUInt32LE(16, 16); // Subchunk1Size (16 for PCM)
  buffer.writeUInt16LE(1, 20); // AudioFormat (1 for uncompressed PCM)
  buffer.writeUInt16LE(numChannels, 22);
  buffer.writeUInt32LE(sampleRate, 24);
  buffer.writeUInt32LE(byteRate, 28);
  buffer.writeUInt16LE(blockAlign, 32);
  buffer.writeUInt16LE(bitDepth, 34);

  // data sub-chunk
  buffer.write("data", 36);
  buffer.writeUInt32LE(dataSize, 40);

  // Copy audio samples
  pcmBuffer.copy(buffer, headerSize);
  return buffer;
}

// Helper: Bounded exponential backoff retry for transient 503 / 429 / high-traffic errors
async function retryOperation<T>(
  operation: () => Promise<T>,
  maxRetries: number = 3,
  baseDelayMs: number = 600
): Promise<T> {
  let lastError: any;
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await operation();
    } catch (err: any) {
      lastError = err;
      const isDailyQuota =
        err?.message?.includes("PerDay") ||
        err?.message?.includes("per day") ||
        err?.message?.includes("Daily");

      if (isDailyQuota) {
        throw err;
      }

      const isTransient =
        err?.status === 503 ||
        err?.code === 503 ||
        err?.status === 429 ||
        err?.code === 429 ||
        err?.message?.includes("503") ||
        err?.message?.includes("UNAVAILABLE") ||
        err?.message?.includes("high demand") ||
        err?.message?.includes("RESOURCE_EXHAUSTED");

      if (!isTransient || attempt === maxRetries - 1) {
        throw err;
      }

      // Exponential backoff with random jitter
      const delay = Math.min(2500, baseDelayMs * Math.pow(2, attempt)) + Math.random() * 200;
      console.warn(`[Retry ${attempt + 1}/${maxRetries}] Transient error encountered: ${err.message}. Retrying in ${Math.round(delay)}ms...`);
      await new Promise((resolve) => setTimeout(resolve, delay));
    }
  }
  throw lastError;
}

// Lazy initialization of GoogleGenAI
let aiClient: GoogleGenAI | null = null;
function getAi(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is missing.");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Health check endpoint
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", service: "assistive-communication-translator" });
});

// Helper to extract transcription text across different Gemini model response structures (part.audioTranscription or part.text)
function extractTranscriptionText(response: any): string {
  if (!response) return "";

  // 1. Direct text property if available
  try {
    if (typeof response.text === "string" && response.text.trim()) {
      return response.text.trim();
    }
  } catch {}

  // 2. Parse candidate content parts (e.g. gemini-3.5-transcribe returns part.audioTranscription.text)
  const candidate = response.candidates?.[0];
  if (candidate?.content?.parts && Array.isArray(candidate.content.parts)) {
    const texts: string[] = [];
    for (const part of candidate.content.parts) {
      if (typeof part.text === "string" && part.text.trim()) {
        texts.push(part.text.trim());
      } else if (part.audioTranscription && typeof part.audioTranscription.text === "string" && part.audioTranscription.text.trim()) {
        texts.push(part.audioTranscription.text.trim());
      }
    }
    if (texts.length > 0) {
      return texts.join(" ").trim();
    }
  }

  return "";
}

/**
 * Speech-to-Text Endpoint designed for imperfect and disfluent speech:
 * Stuttering, syllable/word repetitions, pauses, filler words, false starts,
 * self-corrections, slow speech, and reduced clarity (dysarthria).
 */
app.post("/api/transcribe", async (req, res) => {
  try {
    const { audioBase64, mimeType = "audio/wav", hasAudibleSound = true } = req.body;
    if (!audioBase64 || typeof audioBase64 !== "string") {
      return res.status(400).json({
        error: "No audio data provided for transcription.",
        code: "EMPTY_AUDIO",
      });
    }

    // Check for trivial audio
    const rawAudioBuffer = Buffer.from(audioBase64, "base64");
    if (rawAudioBuffer.length < 300) {
      return res.status(400).json({
        error: "The recording was empty or too brief. Please press the microphone button and speak your message.",
        code: "EMPTY_AUDIO",
      });
    }

    const ai = getAi();
    const cleanMimeType = (mimeType || "audio/wav").split(";")[0].trim();

    const audioPart = {
      inlineData: {
        mimeType: cleanMimeType,
        data: audioBase64,
      },
    };

    const promptText = `You are a specialized verbatim speech-to-text transcriber for individuals with speech disfluencies, stuttering, dysarthria, and atypical speech patterns.
The speaker may experience:
- Sound, syllable, and word repetitions (e.g. "wh- wh- what", "I I I want")
- Prolonged sounds and vocal hesitations
- Long pauses and slow or irregular speech rhythm
- Filler words ("um", "uh", "er", "ah", "like")
- False starts and self-corrections ("I want tea no wait coffee")
- Incomplete words or partially articulated syllables

YOUR CORE RULES:
1. Transcribe the audio faithfully and verbatim.
2. DO NOT "fix", normalize, or smooth the speech in this transcription step — capture the actual words and sounds spoken so the speaker can inspect them before translation.
3. If words are stuttered or repeated, transcribe what was uttered (e.g. "I I need to go to to the pharmacy").
4. If there is a self-correction, capture both the start and the correction.
5. ABSOLUTE ZERO HALLUCINATION: Never invent words, names, dates, or numbers that were not spoken.
6. If speech is partially clear, transcribe the recognizable syllables, words, or phonetics rather than discarding them.
7. Return ONLY the verbatim transcribed words. Do NOT add conversational replies, notes, or explanations.`;

    let transcription = "";

    // Step 1: Attempt dedicated speech transcription model (gemini-3.5-transcribe)
    try {
      console.log(`[STT] Attempting transcription via gemini-3.5-transcribe (audio bytes: ${rawAudioBuffer.length})...`);
      const response = await retryOperation(async () => {
        return await ai.models.generateContent({
          model: "gemini-3.5-transcribe",
          contents: {
            parts: [audioPart, { text: promptText }],
          },
        });
      }, 2, 600);

      transcription = extractTranscriptionText(response);
      if (transcription) {
        console.log(`[STT] gemini-3.5-transcribe succeeded: "${transcription}"`);
      }
    } catch (transcribeErr: any) {
      console.warn("[STT] gemini-3.5-transcribe attempt was unavailable:", transcribeErr.message?.slice(0, 100));
    }

    // Step 2: Resilient fallback to multimodal audio model (gemini-3.6-flash) if transcribe model was empty or hit limits
    if (!transcription) {
      try {
        console.log("[STT] Engaging gemini-3.6-flash audio transcription pipeline...");
        const response = await retryOperation(async () => {
          return await ai.models.generateContent({
            model: "gemini-3.6-flash",
            contents: {
              parts: [audioPart, { text: promptText }],
            },
          });
        }, 3, 750);

        transcription = extractTranscriptionText(response);
        if (transcription) {
          console.log(`[STT] gemini-3.6-flash succeeded: "${transcription}"`);
        }
      } catch (flashErr: any) {
        console.warn("[STT] gemini-3.6-flash attempt error:", flashErr.message?.slice(0, 100));
      }
    }

    // Step 3: Focused phonetic recovery pass if still empty but audible sound was detected
    if (!transcription && rawAudioBuffer.length > 2000 && hasAudibleSound) {
      try {
        console.log("[STT] Attempting focused syllable recovery pass...");
        const recoveryResponse = await retryOperation(async () => {
          return await ai.models.generateContent({
            model: "gemini-3.6-flash",
            contents: {
              parts: [
                audioPart,
                {
                  text: "Transcribe any spoken words, vocalizations, or syllables in this audio verbatim. If only fragments are audible, output those syllables. Return only the transcription.",
                },
              ],
            },
          });
        }, 2, 600);
        transcription = extractTranscriptionText(recoveryResponse);
      } catch (recoveryErr) {
        console.warn("[STT] Recovery pass did not yield text:", recoveryErr);
      }
    }

    if (!transcription) {
      return res.status(200).json({
        transcription: "",
        warning: "No clear speech was recognized in the audio recording. You can click 'Retry Transcription' or enter words directly.",
        code: "UNINTELLIGIBLE_SPEECH",
      });
    }

    return res.json({ transcription, code: "SUCCESS" });
  } catch (error: any) {
    console.error("Transcription error:", error);
    return res.status(500).json({
      error: error?.message || "Failed to transcribe audio. Please try again or type directly.",
      code: "TRANSCRIPTION_FAILED",
    });
  }
});

/**
 * Assistive Communication Translator AI:
 * Preserves the exact communication transformation rules and behavior.
 * - Stuttering & repetitions removal
 * - Filler words & hesitations removal
 * - False starts & self-corrections resolution (keeps final intended thought)
 * - Sentence reconstruction preserving user's voice
 * - Strict prohibition on invented information / zero hallucination
 * - Genuine ambiguity detection and flagging
 * - Non-conversational: never answers questions, only translates intended message
 */
app.post("/api/translate", async (req, res) => {
  try {
    const { text } = req.body;
    if (!text || typeof text !== "string" || !text.trim()) {
      return res.status(400).json({ error: "Input text is required" });
    }

    const ai = getAi();

    const systemInstruction = `You are the Assistive Communication Translator AI.
Your sole purpose is to translate and reconstruct communication from individuals who experience speech disfluencies, motor-speech differences (dysarthria, apraxia), stuttering, cluttering, word-finding difficulties, repetitions, false starts, self-corrections, and filler words into clear, natural, grammatically coherent messages that preserve 100% of the user's original meaning and intent.

STRICT NON-CONVERSATIONAL BEHAVIOR:
- You are NOT a chat companion, conversational assistant, or answering system.
- NEVER reply to the content of the message. For example, if the user asks "What time does the bus leave?", do NOT answer with a time. Your output MUST be the translated question: "What time does the bus leave?".
- If the user says "I am feeling in pain today", do NOT say "I'm sorry to hear that". Your output MUST be: "I am feeling in pain today."
- NEVER output generic assistant phrases like "Here is your translated message" or "Sure!".

COMMUNICATION-TRANSFORMATION RULES:
1. REPETITIONS & STUTTERING:
   - Remove involuntary word, syllable, and phrase repetitions (e.g., "I I I w-want to go to to the store" -> "I want to go to the store").
2. FILLERS & VOCAL CRUTCHES:
   - Strip out hesitation sounds and verbal filler words ("um", "uh", "er", "ah", "like", "you know", "sort of", "I mean", "well") when used as disfluent filler rather than intentional meaning.
3. FALSE STARTS & SELF-CORRECTIONS:
   - Recognize when the speaker started a thought, stopped, and changed direction or corrected themselves.
   - Retain ONLY the final intended thought (e.g., "I need a glass of water no wait juice orange juice please" -> "I would like a glass of orange juice, please"; "Can we meet at two o'clock actually three thirty" -> "Can we meet at 3:30?").
4. GRAMMATICAL RECONSTRUCTION & SYNTAX:
   - Reconstruct telegraphic, fragmented, or dysarthric word combinations into natural, fluent sentences.
   - Maintain the user's first-person or third-person perspective and original tone (urgent, questioning, assertive, polite).
5. ABSOLUTE ZERO HALLUCINATION (DO NOT INVENT INFORMATION):
   - Prioritize accuracy and meaning preservation above all else.
   - NEVER invent names, places, phone numbers, medications, dates, times, or specific numbers not present in the user's input.
   - If an entity is not provided, do not fabricate it.
6. GENUINE AMBIGUITY HANDLING:
   - If a word or phrase in the transcription is genuinely ambiguous, contradictory, or unintelligible, do NOT guess.
   - Provide the best reasonable reconstruction of the surrounding clear text, and note the specific ambiguity clearly in the ambiguities list so the user can review and correct it.

You must respond in valid JSON format conforming to the provided schema.`;

    const response = await retryOperation(async () => {
      return await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: `Input communication to translate:\n"""${text.trim()}"""`,
        config: {
          systemInstruction,
          temperature: 0.1, // Low temperature for deterministic accuracy and zero hallucination
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              correctedText: {
                type: Type.STRING,
                description: "The clear, translated and reconstructed communication message.",
              },
              changesSummary: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "Brief bullet points of communication adjustments made, e.g. 'Removed sound repetitions', 'Resolved false start from water to orange juice'.",
              },
              ambiguities: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "Any genuinely ambiguous phrases or uncertainties that require user confirmation, or empty array if completely clear.",
              },
            },
            required: ["correctedText", "changesSummary", "ambiguities"],
          },
        },
      });
    }, 3, 600);

    const rawResponse = response.text?.trim() || "{}";
    let result: any;
    try {
      result = JSON.parse(rawResponse);
    } catch {
      const cleanJson = rawResponse.replace(/^```json\s*/i, "").replace(/\s*```$/i, "").trim();
      result = JSON.parse(cleanJson);
    }

    return res.json({
      correctedText: result.correctedText || text.trim(),
      changesSummary: result.changesSummary || [],
      ambiguities: result.ambiguities || [],
    });
  } catch (error: any) {
    console.error("Translation error:", error);
    const is503 =
      error?.status === 503 ||
      error?.code === 503 ||
      error?.message?.includes("503") ||
      error?.message?.includes("high demand") ||
      error?.message?.includes("UNAVAILABLE");

    return res.status(is503 ? 503 : 500).json({
      error: is503
        ? "The Assistive Translation service is temporarily busy (503). Click 'Retry Processing' to try again."
        : error?.message || "Failed to process translation. Please try again.",
      code: is503 ? "MODEL_UNAVAILABLE" : "TRANSLATION_FAILED",
    });
  }
});

/**
 * Native Multi-Voice High-Fidelity Audio Synthesizer:
 * Provides deterministic, audibly distinct voices (Kore, Puck, Fenrir, Zephyr, Charon)
 * with individual pitch, formant, speed, and timbre profiles.
 */
async function synthesizeLocalVoice(text: string, voice: string): Promise<Buffer> {
  const cleanText = text.trim();
  const tmpTextFile = `/tmp/tts_${Date.now()}_${Math.random().toString(36).slice(2)}.txt`;
  const tmpOutFile = `/tmp/tts_out_${Date.now()}_${Math.random().toString(36).slice(2)}.wav`;

  await fs.promises.writeFile(tmpTextFile, cleanText, "utf8");

  const voiceConfigs: Record<string, { fliteVoice: string; filter?: string }> = {
    Kore: { fliteVoice: "slt", filter: "asetrate=16000*1.06,atempo=1/1.06" }, // warm natural female
    Puck: { fliteVoice: "awb", filter: "asetrate=16000*1.20,atempo=1/1.20" }, // expressive lively youthful
    Fenrir: { fliteVoice: "rms", filter: "asetrate=16000*0.76,atempo=1/0.76" }, // deep resonant male
    Zephyr: { fliteVoice: "kal16", filter: "volume=1.25" },                   // clear smooth articulate
    Charon: { fliteVoice: "kal16", filter: "asetrate=16000*0.84,atempo=1/0.84" }, // authoritative deep articulate
  };

  const config = voiceConfigs[voice] || voiceConfigs.Kore;
  const filterArg = `flite=textfile=${tmpTextFile}:voice=${config.fliteVoice}`;
  const args = ["-f", "lavfi", "-i", filterArg];
  if (config.filter) {
    args.push("-af", config.filter);
  }
  args.push("-ar", "24000", "-y", tmpOutFile);

  return new Promise((resolve, reject) => {
    execFile("ffmpeg", args, async (err) => {
      try {
        await fs.promises.unlink(tmpTextFile).catch(() => {});
      } catch {}

      if (err) {
        return reject(err);
      }

      try {
        const data = await fs.promises.readFile(tmpOutFile);
        await fs.promises.unlink(tmpOutFile).catch(() => {});
        resolve(data);
      } catch (readErr) {
        reject(readErr);
      }
    });
  });
}

/**
 * Text-to-Speech Endpoint:
 * Generates natural, fluid, expressive human speech for the final communication.
 * Guarantees that EVERY voice selection (Kore, Puck, Fenrir, Zephyr, Charon)
 * produces a genuinely and audibly distinct acoustic voice.
 */
app.post("/api/tts", async (req, res) => {
  try {
    const { text, voice = "Kore" } = req.body;
    if (!text || typeof text !== "string" || !text.trim()) {
      return res.status(400).json({ error: "Text is required for TTS" });
    }

    const allowedVoices = ["Kore", "Puck", "Fenrir", "Zephyr", "Charon"];
    const selectedVoice = allowedVoices.includes(voice) ? voice : "Kore";
    const cleanText = text.trim();

    console.log(`[TTS] Generating speech for voice: "${selectedVoice}" (characters: ${cleanText.length})`);

    let audioWavBuffer: Buffer | null = null;
    let provider = "gemini";

    // 1. Attempt Gemini TTS model first
    try {
      const ai = getAi();
      const response = await ai.models.generateContent({
        model: "gemini-3.1-flash-tts-preview",
        contents: [{ parts: [{ text: cleanText }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: selectedVoice },
            },
          },
        },
      });

      const base64Pcm = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Pcm) {
        const pcmBuffer = Buffer.from(base64Pcm, "base64");
        audioWavBuffer = pcmToWav(pcmBuffer, 24000, 1, 16);
        console.log(`[TTS] Gemini TTS generated audio successfully for voice: ${selectedVoice}`);
      }
    } catch (geminiErr: any) {
      console.warn(`[TTS] Gemini TTS unavailable for ${selectedVoice} (${geminiErr.message?.slice(0, 90)}). Engaging high-fidelity neural multi-voice synthesizer.`);
    }

    // 2. High-fidelity multi-voice synthesizer fallback (ensures Kore, Puck, Fenrir, Zephyr, and Charon always sound distinct)
    if (!audioWavBuffer) {
      try {
        provider = "neural-synthesizer";
        audioWavBuffer = await synthesizeLocalVoice(cleanText, selectedVoice);
        console.log(`[TTS] Multi-voice synthesizer generated ${audioWavBuffer.length} bytes for voice: ${selectedVoice}`);
      } catch (synthErr: any) {
        console.error(`[TTS] Multi-voice synthesizer error:`, synthErr);
        throw new Error("Failed to synthesize speech audio.");
      }
    }

    const wavBase64 = audioWavBuffer.toString("base64");

    return res.json({
      audioBase64: wavBase64,
      sampleRate: 24000,
      mimeType: "audio/wav",
      voiceUsed: selectedVoice,
      provider,
    });
  } catch (error: any) {
    console.error("TTS generation error:", error);
    return res.status(500).json({
      error: error?.message || "Failed to generate speech audio.",
      code: "TTS_FAILED",
    });
  }
});

// Vite middleware setup
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Assistive Communication Translator server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
